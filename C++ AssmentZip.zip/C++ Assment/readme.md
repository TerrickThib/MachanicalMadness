## Locate and open the Game Executable(.exe) to open the game.
# How to Play
W,A,S,D to move
Press Space to use your Sword, but be careful, you can't move while attacking!
Press Escape to Close the game, don't press it on accident! :)

# Goal
You are particpating in a very offical and regular test. You control the robot, Robi. You're mission is simple, reach the Victory Pad at the top of the screen. However, don't think its too easy, enemies will try to stop you! Use your robot's sword to defeat them. Don't worry, they're replacable. 

Some of the enemies also have swords as well so don't get too close. Those enemies also can drop a Sword Upgrade, but only sometimes, the Sphere Enemies also can drop a power up, although it is rarer. You __Defenitely__ can't hold "P" down to make the powerup always drop. Its just doesn't work. Don't Try it. Nothing will happen. It is not a valid input. I know what you're thinking and you're wrong. Why am I even telling you this if there is no point to the "P" key? I don't know. I guess I just wanted to.

# Noticable Bugs
The ranged sword powerup's Hitbox is disjointed from its sprite, so it can hit or miss when the opposite should occur.
While not a 'bug', the sword enemies will kill you on the first frame of their sword animation, so you will not see it. Just keep that in mind when you die 'randomly', unless you actually do just die randomly. In this case, please inform us.